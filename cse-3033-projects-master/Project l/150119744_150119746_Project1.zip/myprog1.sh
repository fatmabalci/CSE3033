# CSE 3033 Operating Systems - Assignment 1 / Question 1
# Authors: Fatma Balci (150119744) - Alper Dokay (150119746)

# checking the argument whether it is NULL or not.
if [ -z $1 ]
then
    echo "Error - No filename is given"
    exit 1
fi

# read the document
while read line
do
    format=$(printf "%${line}s")  # set the format for starts
    echo "$line ${format// /*}"  # print the stars
done <<< "$(cat $1)"  # process file