# CSE 3033 Operating Systems - Assignment 1 / Question 3
# Authors: Fatma Balci (150119744) - Alper Dokay (150119746)

# checking the argument whether it is NULL or not.
if [ -z $1 ]
then
    echo "Error - No directory name is given"
    exit 1
fi

dirName=$1  # assign argument to a variable

# find the values in that dir that is not
# Makefile or contain .c and .h documents and not directories (specified by -f)
values=`find $dirName -type f -not -name "Makefile" -and -not -name "*.c" -and -not -name "*.h"`

# iterate through each value to remove
for value in $values
do
    echo "Removing $value"
    rm $value  # remove the files
done