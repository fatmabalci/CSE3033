# CSE 3033 Operating Systems - Assignment 1 / Question 3
# Authors: Fatma Balci (150119744) - Alper Dokay (150119746)


# checking the filename argument whether it is NULL or not.
if [ -z $1 ]
then
    echo "Error - No filename is given"
    exit 1
fi

# checking the first word argument whether it is NULL or not.
if [ -z $2 ]
then
    echo "Error - No search word is given"
    exit 1
fi

# checking the second word argument whether it is NULL or not.
if [ -z $3 ]
then
    echo "Error - No replacement word is given"
    exit 1
fi

# newFile txt
newFile="" 
counter=0
# defined to count matchings

# going through each line

while read line; do
    for word in $line; do  # going through each word
        if [ $word = apple ]
        then
            newFile+="orange "  # add orange instead of apple
            ((counter=counter+1))
            # increment counter
        else
            newFile+=$word  # add word as it was
            newFile+=" "  # add a space here
        fi
    done
done < $1

# print the result
echo "All $counter occurrences of \"apple\" in \"$1\" has changed with \"orange\""

echo $newFile > $1 # write back