# CSE 3033 Operating Systems - Assignment 1 / Question 4
# Authors: Fatma Balci (150119744) - Alper Dokay (150119746)

# remove directories if exist
rmdir smallest
rmdir largest
# make directories
mkdir smallest
mkdir largest

# find the smallest file
smallestFileInTheDir=`find $PWD -type f -printf '%s - %p\n' | sort | head -n 1`

# take it to array for zero index  (sorting purposes)
IFS='/' read -r -a pathArray <<< "$smallestFileInTheDir"
# get smallest file name
smallestFile="${pathArray[-1]}"

# move it to the smallest dir
mv $smallestFile smallest

# find the largest file
largestFileInTheDir=`find $PWD -type f -printf '%s\t%p\n' | sort -n -r | head -n 1`

# take it to array for zero index (sorting purposes)
IFS='/' read -r -a newArray <<< "$largestFileInTheDir"
# get largest file name
largestFile="${newArray[-1]}"

# move it to the largest dir
mv $largestFile largest