# CSE 3033 Operating Systems - Assignment 1 / Question 4
# Authors: Fatma Balci (150119744) - Alper Dokay (150119746)

# checking the argument whether it is NULL or not.
if [ -z $1 ]
then
    echo "Error - No number is given"
    exit 1
fi

# assigning it to a variable
number=$1

# create a total to do calculations
total=0

# go through as long as it is greater than zero
while [ $number -gt 0 ]
do
    # take its mode with 10 to get the latest number
    k=$(( $number % 10))

    # divide the original number by 10 to get other digits
    number=$(( $number / 10))

    # take its mode with 10 again as it will give the second number from right-side
    l=$(( $number % 10))

    # if there is no number any other number, finish it
    if [ $l -gt 0 ]
    then

    # summing them up by multiplying the latest digit with 10 and the second as normal
    total=$(( $total + ($k * 10) + $l ))

    fi
done

# if the given number has only one digit
if [ $total -eq 0 ]
then
total=$1  # make it equal to the digit itself
fi

# print the result
echo $total